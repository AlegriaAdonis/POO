/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg1p1tarea1alegriaadonis;
import java.util.Scanner;
/**
 *
 * @author alegr
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        System.out.print("----------------------------------");
        
        System.out.print("Ingrese 2 numeros para multiplicar");
        System.out.print("----------------------------------");
        System.out.print("Ingrese el primer numero: ");
        double n1= scanner.nextDouble();
        System.out.print("Ingrese el segundo numero: ");
        double n2= scanner.nextDouble();
        double multi=n1*n2;
        System.out.print("----------------------------------");
        System.out.print("La multiplicacion de los 2 numeros es: "+ multi);
        System.out.print("----------------------------------");
        scanner.close();
    }
    
}
